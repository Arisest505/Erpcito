<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Storage;
use ZipArchive;

class BackupController extends Controller
{
    public function createAndDownload()
    {
        // Ejecutar el comando de respaldo
        Artisan::call('backup:run');

        // Obtener el último archivo de respaldo
        $backupPath = $this->getLastBackupPath();

        // Verificar si se encontró un archivo de respaldo
        if (!$backupPath) {
            return response()->json(['error' => 'No se encontraron archivos de respaldo'], 404);
        }

        // Nombre del archivo zip a descargar
        $zipFileName = 'backup-' . date('Y-m-d_H-i-s') . '.zip';
        $zipFilePath = storage_path('app/' . $zipFileName);

        // Crear archivo zip
        $zip = new ZipArchive;
        if ($zip->open($zipFilePath, ZipArchive::CREATE) !== true) {
            return response()->json(['error' => 'No se pudo crear el archivo zip'], 500);
        }

        $zip->addFile($backupPath, basename($backupPath));
        $zip->close();


        // Ajustar los permisos del archivo ZIP
        chmod($zipFilePath, 0666); // Permisos de lectura y escritura para todos los usuarios




        // Descargar el archivo zip
        return response()->download($zipFilePath)->deleteFileAfterSend(true);
    }

    protected function getLastBackupPath()
    {
        // Obtener la ruta del directorio de respaldos
        $backupDirectory = storage_path('app/backups');

        // Obtener todos los archivos en el directorio de respaldos
        $files = scandir($backupDirectory);
        // Eliminar los directorios . y ..
        $files = array_diff($files, ['.', '..']);

        // Ordenar los archivos por fecha de modificación descendente
        arsort($files);

        // Obtener el primer archivo (último respaldo)
        $latestBackup = reset($files);

        if (!$latestBackup) {
            return null;
        }

        // Devolver la ruta completa del último respaldo
        return $backupDirectory . DIRECTORY_SEPARATOR . $latestBackup;
    }
}
