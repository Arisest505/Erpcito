<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Collection;

class BackupController extends Controller
{
    public function create()
    {
        // Ejecutar el comando de respaldo
        Artisan::call('backup:run');

        // Obtener el último archivo de respaldo
        $disk = Storage::disk(config('backup.destination.disks')[0]);
        $files = new Collection($disk->files(config('backup.destination.folder')));

        // Obtener el archivo más reciente
        $latestBackupFile = $files->sortByDesc(function ($file) use ($disk) {
            return $disk->lastModified($file);
        })->first();

        // Obtener la ruta completa del archivo
        $path = storage_path('app/' . config('backup.destination.folder') . '/' . $latestBackupFile);

        return response()->download($path);
    }
}

