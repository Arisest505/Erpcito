<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Collection;

class BackupController extends Controller
{
    public function create()
    {
        // Ejecutar el comando de respaldo
        Artisan::call('backup:run');

        // Obtener la configuración de destino de respaldo
        $destinationDisks = config('backup.destination.disks');

        // Verificar si la configuración de discos está presente y es válida
        if (!$destinationDisks || !is_array($destinationDisks) || empty($destinationDisks)) {
            return response()->json(['error' => 'Configuración de discos de respaldo no válida'], 500);
        }

        // Obtener el nombre del primer disco de respaldo
        $firstDisk = reset($destinationDisks);

        // Obtener el disco de almacenamiento
        $disk = Storage::disk($firstDisk);

        // Obtener los archivos de respaldo
        $files = new Collection($disk->files(config('backup.destination.folder')));

        // Verificar si hay archivos de respaldo disponibles
        if ($files->isEmpty()) {
            return response()->json(['error' => 'No se encontraron archivos de respaldo'], 404);
        }

        // Obtener el archivo más reciente
        $latestBackupFile = $files->sortByDesc(function ($file) use ($disk) {
            return $disk->lastModified($file);
        })->first();

        // Obtener la ruta completa del archivo
        $path = storage_path('app/' . config('backup.destination.folder') . '/' . $latestBackupFile);

        // Descargar el archivo de respaldo
        return response()->download($path);
    }
}
