<!-- resources/views/categoria_productos.blade.php -->

@extends('layouts.app')

@section('content')
    <!-- Contenido específico de Categoría Productos -->
    <div class="container">
        <h2>Categoría Productos</h2>
        <p>Contenido de la categoría de productos aquí...</p>
    </div>
@endsection
